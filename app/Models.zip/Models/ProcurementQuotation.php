<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ProcurementQuotation extends Model
{
    /** @use HasFactory<\Database\Factories\ProcurementQuotationFactory> */
    use HasFactory;
}
